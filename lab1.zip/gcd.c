#include<gmp.h>
#include <time.h>

int main()
{
	mpz_t x;
	mpz_t y;
	mpz_t t;
	mpz_t maximum;
	mpz_inits(x,y,t,maximum,NULL);
	gmp_randstate_t state;
	gmp_randinit_mt(state);
	unsigned long seed=time(NULL);
	gmp_randseed_ui(state,seed);
	mpz_set_ui(maximum,1000000);
	mpz_urandomm(x,state,maximum);
	mpz_urandomm(y,state,maximum);
	gmp_printf("random value of 1st number is: ");
	gmp_printf(" %Zd\n",x);
	gmp_printf("random value of 2nd number is: ");
	gmp_printf("%Zd\n",y);
	while(mpz_cmp_ui(y,0)!=0)
	{
		mpz_set(t,y);
		mpz_mod(y,x,t);
		mpz_set(x,t);
	}
	gmp_printf("GCD of given 2 numbers is %Zd\n",x);
return 0;
}
