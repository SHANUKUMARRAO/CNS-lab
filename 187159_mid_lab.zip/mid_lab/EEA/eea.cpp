//Extended Euclidean Algorithm (EEA)

#include<bits/stdc++.h>
using namespace std;
//Input: positive integers r0 and r1 with r0 > r1
//Output: gcd(r0,r1), as well as s and t such that gcd(r0,r1) = s·r0 +t ·r1.
long gcd(long r0, long r1, long * s, long * t){
//Initialization:
		//s0=1 t0=0
		//s1=0 t1=1

	long q, r;
	long s0, t1 = 1;
	long s1, t0 = 0;

	if (r1 == 0) {
		*s = 1;
		*t = 0;
		return r0;
	}

	while(r1 > 0) {
		q = r0 / r1;
		r = r0 - q * r1;
		
		*s = s0 - q * s1;
		*t = t0 - q * t1;
		
		r0 = r1;
		r1 = r;

		s0 = s1;
		s1 = *s;
		t0 = t1;
		t1 = *t;
	}
	
	*s = s0;
	*t = t0;

	return r0;

}


int main(){

	long X, N; //input

	long G, I; //output

	long s, t; //s and t pointers

	long aux;
	cout<<"enter the x and n\n";
	cin>>X>>N; //reading

	/* Need to X>N since Meneze's takes a>b */
	if (X<N){ 
		aux = X;
		X = N;
		N = aux;
	}

	G = gcd(X, N, &s, &t); //GCD

	/* t Mod N if t is negative to obtain a positive value for its inverse */
	I = t;
	while (I < 0){
		I = t + X;
	}
	cout<<"gcd(r0,r1), as well as s and t such that gcd(r0,r1) = s·r0 +t ·r1.\n";
	if ( G == 1){ //Inverse exists
		cout<<G<<"  "<<I;
	}else{
		cout<<G<<endl;	
	}

	return 0;
}
