#include<bits/stdc++.h>
#include <sys/stat.h>
#include <sys/types.h>
#include<sys/wait.h> 
#include <unistd.h>
#include<fcntl.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include "aes_header.h"
typedef unsigned char C;
using namespace std;
void add_key(C *msg, C *key) 
{
	for (int i = 0; i < 16; i++)
	msg[i] ^= key[i];
}
void substitution(C *msg)
{
	for(int i=0;i<16;i++)
	msg[i]=s[msg[i]];
}
void rotate(C *A,int n)
{
	for(int i=0;i<n;i++)
	{
		C x=A[0];
		for(int j=0;j<3;j++)
		A[j]=A[j+1];
		A[3]=x;
	}
}
void row_shit(C *msg)
{
	C matrix[4][4];
	for(int i=0;i<4;i++)
	for(int j=0;j<4;j++)
	matrix[j][i]=msg[(i*4)+j];
	C x;
	//second column
	rotate(matrix[1],1);
	rotate(matrix[2],2);
	rotate(matrix[3],3);
	for(int i=0;i<4;i++)
	for(int j=0;j<4;j++)
	msg[(i*4)+j]=matrix[j][i];
}
void mix_columns(unsigned char * msg) {
	unsigned char tmp[16];

	tmp[0] = (unsigned char) mul2[msg[0]] ^ mul3[msg[1]] ^ msg[2] ^ msg[3];
	tmp[1] = (unsigned char) msg[0] ^ mul2[msg[1]] ^ mul3[msg[2]] ^ msg[3];
	tmp[2] = (unsigned char) msg[0] ^ msg[1] ^ mul2[msg[2]] ^ mul3[msg[3]];
	tmp[3] = (unsigned char) mul3[msg[0]] ^ msg[1] ^ msg[2] ^ mul2[msg[3]];

	tmp[4] = (unsigned char)mul2[msg[4]] ^ mul3[msg[5]] ^ msg[6] ^ msg[7];
	tmp[5] = (unsigned char)msg[4] ^ mul2[msg[5]] ^ mul3[msg[6]] ^ msg[7];
	tmp[6] = (unsigned char)msg[4] ^ msg[5] ^ mul2[msg[6]] ^ mul3[msg[7]];
	tmp[7] = (unsigned char)mul3[msg[4]] ^ msg[5] ^ msg[6] ^ mul2[msg[7]];

	tmp[8] = (unsigned char)mul2[msg[8]] ^ mul3[msg[9]] ^ msg[10] ^ msg[11];
	tmp[9] = (unsigned char)msg[8] ^ mul2[msg[9]] ^ mul3[msg[10]] ^ msg[11];
	tmp[10] = (unsigned char)msg[8] ^ msg[9] ^ mul2[msg[10]] ^ mul3[msg[11]];
	tmp[11] = (unsigned char)mul3[msg[8]] ^ msg[9] ^ msg[10] ^ mul2[msg[11]];

	tmp[12] = (unsigned char)mul2[msg[12]] ^ mul3[msg[13]] ^ msg[14] ^ msg[15];
	tmp[13] = (unsigned char)msg[12] ^ mul2[msg[13]] ^ mul3[msg[14]] ^ msg[15];
	tmp[14] = (unsigned char)msg[12] ^ msg[13] ^ mul2[msg[14]] ^ mul3[msg[15]];
	tmp[15] = (unsigned char)mul3[msg[12]] ^ msg[13] ^ msg[14] ^ mul2[msg[15]];

	for (int i = 0; i < 16; i++)
	msg[i] = tmp[i];
}
void round(C *msg,C *key)
{
	substitution(msg);
	row_shit(msg);
	mix_columns(msg);
	add_key(msg,key);
}
void final(C *msg,C *key)
{
	substitution(msg);
	row_shit(msg);
	add_key(msg,key);
}
void encryption(C *msg,C *key)
{
	add_key(msg,key);
	for(int i=0;i<9;i++)
	round(msg , key + (16 * (i+1)));
	final(msg,key+160);
}
int main(int argc,char* argv[])
{
	cout<<"######### SERVER SIDE #########"<<endl;
	int sfd,pno;
	struct sockaddr_in ser_addr,cli_addr;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd<0)
	{
		perror("sfd not created\n");
		exit(0);
	}
	pno=atoi(argv[1]);
	bzero((char *) &ser_addr,sizeof(ser_addr));
	ser_addr.sin_family=AF_INET;
	ser_addr.sin_addr.s_addr=INADDR_ANY;
	ser_addr.sin_port=htons(pno);
	if(bind(sfd,(struct sockaddr *) &ser_addr,sizeof(ser_addr))<0)
	{
		perror("binding error\n");
		exit(0);
	}
	if(listen(sfd,10)!=0)
	{perror("Listen error\n");exit(0);}
	else
	{printf("Server is listening\n");}
	socklen_t x=sizeof(cli_addr);
	int nsfd=accept(sfd,(struct sockaddr *) &cli_addr,&x);
	printf("Connected to Client,Now send data\n");
	if(nsfd<0)
	{
		perror("nsfd error\n");
		exit(0);
	}
	C key_given[] = "aAbBcCdDeEfFgGhH";
	unsigned char expandedKey[176];
	KeyExpansion(key_given, expandedKey);
	while(1)
	{
	string s;
	cout<<"Enter message : \n";
	cin>>s;
	//as msg is of 7 bit only we have to convert it to 8 bit
	C *msg_8_bit = new unsigned char[16];
	for(int i=0;i<16;i++)
	msg_8_bit[i] = (C)s[i];
	C encrypted[17];
	encrypted[16]='\0';
	encryption(msg_8_bit,expandedKey);
	for(int i=0;i<16;i++)
	encrypted[i]=msg_8_bit[i];
	write(nsfd,encrypted,sizeof(encrypted));
	cout<<"Encrypted message is : ";
	cout<<encrypted<<endl;
	cout<<"Data is successfully sent\n";
	}
	close(sfd);
	return 0;
}
