#include<bits/stdc++.h>
#include <sys/stat.h>
#include <sys/types.h>
#include<sys/wait.h> 
#include <unistd.h>
#include<fcntl.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include "aes_header.h"
typedef unsigned char C;
using namespace std;
void add_key(C *msg, C *key)
{
	for (int i = 0; i < 16; i++)
	msg[i] ^= key[i];
}
void substitution_inv(C *msg)
{
	for(int i=0;i<16;i++)
	msg[i]=inv_s[msg[i]];
}
void rotate_rev(C *A,int n)
{
	for(int i=0;i<n;i++)
	{
		C x=A[3];
		for(int j=3;j>0;j--)
		A[j]=A[j-1];
		A[0]=x;
	}
}
void row_shit_inv(C *msg)
{
	C matrix[4][4];
	for(int i=0;i<4;i++)
	for(int j=0;j<4;j++)
	matrix[j][i]=msg[(i*4)+j];
	C x;
	//second column
	rotate_rev(matrix[1],1);
	rotate_rev(matrix[2],2);
	rotate_rev(matrix[3],3);
	for(int i=0;i<4;i++)
	for(int j=0;j<4;j++)
	msg[(i*4)+j]=matrix[j][i];
}
void mix_columns_inv(C *msg) {
	unsigned char tmp[16];

	tmp[0] = (unsigned char)mul14[msg[0]] ^ mul11[msg[1]] ^ mul13[msg[2]] ^ mul9[msg[3]];
	tmp[1] = (unsigned char)mul9[msg[0]] ^ mul14[msg[1]] ^ mul11[msg[2]] ^ mul13[msg[3]];
	tmp[2] = (unsigned char)mul13[msg[0]] ^ mul9[msg[1]] ^ mul14[msg[2]] ^ mul11[msg[3]];
	tmp[3] = (unsigned char)mul11[msg[0]] ^ mul13[msg[1]] ^ mul9[msg[2]] ^ mul14[msg[3]];

	tmp[4] = (unsigned char)mul14[msg[4]] ^ mul11[msg[5]] ^ mul13[msg[6]] ^ mul9[msg[7]];
	tmp[5] = (unsigned char)mul9[msg[4]] ^ mul14[msg[5]] ^ mul11[msg[6]] ^ mul13[msg[7]];
	tmp[6] = (unsigned char)mul13[msg[4]] ^ mul9[msg[5]] ^ mul14[msg[6]] ^ mul11[msg[7]];
	tmp[7] = (unsigned char)mul11[msg[4]] ^ mul13[msg[5]] ^ mul9[msg[6]] ^ mul14[msg[7]];

	tmp[8] = (unsigned char)mul14[msg[8]] ^ mul11[msg[9]] ^ mul13[msg[10]] ^ mul9[msg[11]];
	tmp[9] = (unsigned char)mul9[msg[8]] ^ mul14[msg[9]] ^ mul11[msg[10]] ^ mul13[msg[11]];
	tmp[10] = (unsigned char)mul13[msg[8]] ^ mul9[msg[9]] ^ mul14[msg[10]] ^ mul11[msg[11]];
	tmp[11] = (unsigned char)mul11[msg[8]] ^ mul13[msg[9]] ^ mul9[msg[10]] ^ mul14[msg[11]];

	tmp[12] = (unsigned char)mul14[msg[12]] ^ mul11[msg[13]] ^ mul13[msg[14]] ^ mul9[msg[15]];
	tmp[13] = (unsigned char)mul9[msg[12]] ^ mul14[msg[13]] ^ mul11[msg[14]] ^ mul13[msg[15]];
	tmp[14] = (unsigned char)mul13[msg[12]] ^ mul9[msg[13]] ^ mul14[msg[14]] ^ mul11[msg[15]];
	tmp[15] = (unsigned char)mul11[msg[12]] ^ mul13[msg[13]] ^ mul9[msg[14]] ^ mul14[msg[15]];

	for (int i = 0; i < 16; i++)
	msg[i] = tmp[i];
}
void round(C *msg,C *key)
{
	add_key(msg,key);
	mix_columns_inv(msg);
	row_shit_inv(msg);
	substitution_inv(msg);
}
void first(C *msg,C *key)
{
	add_key(msg,key);
	row_shit_inv(msg);
	substitution_inv(msg);
}
void decryption(C *msg,C *key)
{
	first(msg,key+160);
	for(int i=8;i>= 0;i--)
	round(msg , key + (16 * (i+1)));
	add_key(msg,key);
}
int main(int argc,char* argv[])
{
	cout<<"######### CLIENT SIDE #########"<<endl;
	int sfd;
	struct sockaddr_in ser_addr;
	int pno=atoi(argv[1]);
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd<0)
	{
		perror("sfd not created\n");
		exit(0);
	}
	struct hostent *server;
	server=gethostbyname(argv[2]);
	if(server == NULL)
	{
		perror("server getname error\n");
		exit(0);
	}
	bzero((char *) &ser_addr,sizeof(ser_addr));
	ser_addr.sin_family=AF_INET;
	bcopy((char *) server->h_addr,(char *) &ser_addr.sin_addr.s_addr,server->h_length);
	ser_addr.sin_port=htons(pno);
	if(connect(sfd,(struct sockaddr *) &ser_addr,sizeof(ser_addr))<0)
	{
		perror("connect error\n");
		exit(0);
	}
	else
	{printf("connected\n");}
	C key_given[] = "aAbBcCdDeEfFgGhH";
	unsigned char expandedKey[176];
	KeyExpansion(key_given, expandedKey);
	while(1)
	{
	//as msg is of 7 bit only we have to convert it to 8 bit
	C msg_8_bit [16];
	bzero(&msg_8_bit,sizeof(msg_8_bit));
	read(sfd,msg_8_bit,sizeof(msg_8_bit));
	cout<<"received msg : ";
	for(int i=0;i<16;i++)
	cout<<msg_8_bit[i];
	cout<<endl;
	C decrypted[17];
	decrypted[16]='\0';
	decryption(msg_8_bit,expandedKey);
	for(int i=0;i<16;i++)
	decrypted[i]=msg_8_bit[i];
	cout<<"message after decryption : ";
	cout<<decrypted<<endl;
	read(sfd,msg_8_bit,sizeof(msg_8_bit));
	cout<<"waiting for next.......\n";
	}
	return 0;
}
