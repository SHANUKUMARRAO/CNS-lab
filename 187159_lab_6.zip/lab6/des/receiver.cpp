#include<bits/stdc++.h>
#include <sys/stat.h>
#include <sys/types.h>
#include<sys/wait.h> 
#include <unistd.h>
#include<fcntl.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
using namespace std;
int IP[64]={58,50,42,34,26,18,10,2,
			60,52,44,36,28,20,12,4,
			62,54,46,38,30,22,14,6,
			64,56,48,40,32,24,16,8,
			57,49,41,33,25,17,9,1,
			59,51,43,35,27,19,11,3,
			61,53,45,37,29,21,13,5,
			63,55,47,39,31,23,15,7};
int IP_inverse[64];
int E[48]={32,1,2,3,4,5,
			4,5,6,7,8,9,
			8,9,10,11,12,13,
			12,13,14,15,16,17,
			16,17,18,19,20,21,
			20,21,22,23,24,25,
			24,25,26,27,28,29,
			28,29,30,31,32,1};
int P[32]={16,7,20,21,29,12,28,17,
		   1,15,23,26,5,18,31,10,
		   2,8,24,14,32,27,3,9,
		   19,13,30,6,22,11,4,25};
int s[8][4][16] = { { 14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7, 
                          0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8, 
                          4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0, 
                          15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13 }, 
                        { 15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10, 
                          3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5, 
                          0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15, 
                          13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9 },
                        { 10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8, 
                          13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1, 
                          13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7, 
                          1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12 }, 
                        { 7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15, 
                          13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9, 
                          10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4, 
                          3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14 }, 
                        { 2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9, 
                          14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6, 
                          4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14, 
                          11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3 }, 
                        { 12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11, 
                          10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8, 
                          9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6, 
                          4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13 }, 
                        { 4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1, 
                          13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6, 
                          1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2, 
                          6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12 }, 
                        { 13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7, 
                          1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2, 
                          7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8, 
                          2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11 } };
void printVec(vector<bool> &key)
{
	for(int i=0;i<key.size();i++)
	cout<<key[i];
	cout<<endl;
}
void form_IP_inverse()
{
	for(int i=0;i<64;i++)
	IP_inverse[IP[i]-1]=i+1;
}
vector<bool> get_binary(int val,int len){
	vector<bool> ans(len,0);
	int i=len-1;
	while(val>0){
		ans[i]=bool(val%2);
		val/=2;
		i--;
	}
	return ans;
}
void get_char_bin_map(map<char,vector<bool> > &char_bin)
{
	for(int i=0;i<52;i++)
	{
		char c='a';
		int p=0;
		if(i>=26)
		{
			c='A';
			p=26;
		}
		char_bin[char(c+(i-p))] = get_binary(i,8);
	}
}
void get_bin_char(map<char,vector<bool> > &char_bin,map<vector<bool>,char> &bin_char)
{
	map<char,vector<bool> > :: iterator it;
	for(it=char_bin.begin();it!=char_bin.end();++it)
	bin_char[it->second]=it->first;
}
void permutate(vector<bool> &a,int table[])
{
	vector<bool> t;
	for(int i=0;i<a.size();i++)
	t.push_back(a[table[i]-1]);
	a.clear();
	a=t;
}
void expansion(vector<bool> &r)
{
	vector<bool> t;
	for(int i=0;i<48;i++)
	t.push_back(r[E[i]-1]);
	r.clear();
	r=t;
}
void XOR(vector<bool> &a,vector<bool> &b){
	for(int i=0;i<a.size();i++)
		a[i]=a[i]^b[i];
}
int binToDec(vector<bool> &bin){
	int out=0;
	for(int i=0;i<bin.size();i++)
		out=out*2+bin[i];
	return out;
}
vector<bool> box_operation(vector<bool> t,int box_number)
{
	vector<bool> row,col(t.begin()+1,t.end()-1);
	row.push_back(t[0]);
	row.push_back(t[t.size()-1]);
	int x=binToDec(row);
	int y=binToDec(col);
	int value=s[box_number][x][y];
	return get_binary(value,4);
}
vector<bool> s_box(vector<bool> r)
{
	vector<bool> ans;
	for(int i=0;i<48;i=i+6)
	{
		int box_number=i/6;
		vector<bool> t;
		t.insert(t.begin(),r.begin()+i,r.begin()+i+6);
		t=box_operation(t,box_number);
		ans.insert(ans.end(),t.begin(),t.end());
	}
	return ans;
}
vector<bool> f(vector<bool> r,vector<bool> key)
{
	expansion(r);
	XOR(r,key);
	vector<bool> s_box_output=s_box(r);
	permutate(s_box_output,P);
	return s_box_output;
}
void round(vector<bool> &l,vector<bool> &r,vector<bool> key)
{
	vector<bool> r_f=f(r,key);
	XOR(l,r_f);
	vector<bool> t=l;
	l.clear();
	l=r;
	r.clear();
	r=t;
}
void right_circular_shift(vector<bool> &a)
{
	bool c=a[a.size()-1];
	a.pop_back();
	a.insert(a.begin(),c);
}
vector<bool> key_transform(vector<bool> &c,vector<bool> &d,int round_number)
{
	if(round_number!=1)
	{
	right_circular_shift(c);
	right_circular_shift(d);
	if(!(round_number==2 || round_number==9 || round_number==16))
	{
		right_circular_shift(c);
		right_circular_shift(d);
	}
	}
	int PC2[48]={14,17,11,24,1,5,3,28,
				 15,6,21,10,23,19,12,4,
				 26,8,16,7,27,20,13,2,
				 41,52,31,37,47,55,30,40,
				 51,45,33,48,44,49,39,56,
				 34,53,46,42,50,36,29,32};
	vector<bool> t;
	t.insert(t.end(),c.begin(),c.end());
	t.insert(t.end(),d.begin(),d.end());
	vector<bool> temp;
	for(int i=0;i<48;i++)
	temp.push_back(t[PC2[i]-1]);
	return temp;
}
vector<bool> string_to_bin(string s,map<char,vector<bool> > &char_bin)
{
	vector<bool> bit_string;
	for(int i=0;i<s.length();i++)
	bit_string.insert(bit_string.end(), char_bin[s[i]].begin(), char_bin[s[i]].end());
	return bit_string;
}
vector<bool> des_decryption(vector<bool> bit_string,vector<bool> key)
{
	permutate(bit_string,IP);
	vector<bool> ans;
	int mid=(bit_string.size())/2;
	vector<bool> l(bit_string.begin(),bit_string.begin()+mid),r(bit_string.begin()+mid,bit_string.end());
	int PC1[56] = {57,49,41,33,25,17,9,1,
				   58,50,42,34,26,18,10,2,
				   59,51,43,35,27,19,11,3,
				   60,52,44,36,63,55,47,39,
				   31,23,15,7,62,54,46,38,
				   30,22,14,6,61,53,45,37,
				   29,21,13,5,28,20,12,4};
	vector<bool> key_select;
	for(int i=0;i<56;i++)
	key_select.push_back(key[PC1[i]-1]);
	key.clear();
	key=key_select;
	mid=(key.size())/2;
	vector<bool> c(key.begin(),key.begin()+mid),d(key.begin()+mid,key.end());
	for(int i=0;i<16;i++)
	{
		vector<bool> key_value=key_transform(c,d,i+1);
		round(l,r,key_value);
	}
	vector<bool> temp=l;
	l.clear();
	l=r;
	r.clear();
	r=temp;
	l.insert(l.end(),r.begin(),r.end());
	permutate(l,IP_inverse);
	return l;
}
void get_string(string &s,vector<bool> &decrypted_string,map<vector<bool>,char> &bin_char)
{
	for(int i=0;i<64;i+=8)
	{
		vector<bool> vec(decrypted_string.begin()+i,decrypted_string.begin()+i+8);
		s.push_back(bin_char[vec]);
	}
}
int main(int argc,char* argv[])
{
	cout<<"######### CLIENT SIDE #########"<<endl;
	int sfd;
	struct sockaddr_in ser_addr;
	int pno=atoi(argv[1]);
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd<0)
	{
		perror("sfd not created\n");
		exit(0);
	}
	struct hostent *server;
	server=gethostbyname(argv[2]);
	if(server == NULL)
	{
		perror("server getname error\n");
		exit(0);
	}
	bzero((char *) &ser_addr,sizeof(ser_addr));
	ser_addr.sin_family=AF_INET;
	bcopy((char *) server->h_addr,(char *) &ser_addr.sin_addr.s_addr,server->h_length);
	ser_addr.sin_port=htons(pno);
	if(connect(sfd,(struct sockaddr *) &ser_addr,sizeof(ser_addr))<0)
	{
		perror("connect error\n");
		exit(0);
	}
	else
	{printf("connected\n");}
	map<char,vector<bool> > char_bin;
	map<vector<bool>,char> bin_char;
	form_IP_inverse();
	get_char_bin_map(char_bin);
	get_bin_char(char_bin,bin_char);
	while(1)
	{
	char x[100];
	bzero(&x,sizeof(x));
	read(sfd,x,100);
	string s;
	for(int i=0;i<64;i++)
	s.push_back(x[i]);
	cout<<"Received message bits : ";
	cout<<s<<endl;
	vector<bool> bit_string=string_to_bin(s,char_bin);
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='1')
		bit_string.push_back(1);
		else
		bit_string.push_back(0);
	}
	string k="aAbBcCdD";
	vector<bool> key=string_to_bin(k,char_bin);
	cout<<"Key : ";
	printVec(key);
	vector<bool> decrypted_string=des_decryption(bit_string,key);
	s.clear();
	get_string(s,decrypted_string,bin_char);
	cout<<"Decrypted message bits : ";
	printVec(decrypted_string);
	cout<<"Actual message : ";
	cout<<s<<endl;
	cout<<"waiting for next.......\n";
	}
	return 0;
}
