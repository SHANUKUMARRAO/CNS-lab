#include<gmp.h>
#include<stdio.h>
#include<unistd.h>
#include <assert.h>
#include <stdlib.h>

void main()
{
	mpz_t a,b,q,r1,r2,r,s1,s2,s,t1,t2,t,tmp;
	mpz_inits(a,b,q,r1,r2,r,s1,s2,s,t1,t2,t,tmp,NULL);
	
	
	gmp_printf("enter value of a : ");
	gmp_scanf("%Zd",a);
	gmp_printf("enter value of b : ");
	gmp_scanf("%Zd",b);
	
	mpz_set(r1,a);
	mpz_set(r2,b);
	mpz_set_ui(s1,1);
	mpz_set_ui(s2,0);
	mpz_set_ui(t1,0);
	mpz_set_ui(t2,1);
	
	while(mpz_cmp_ui(r2,0)!=0)
	{
		mpz_fdiv_r(r,r1,r2);
		mpz_fdiv_q(q,r1,r2);
		
		mpz_mul(tmp,q,s2);
		mpz_sub(s,s1,tmp);
		
		mpz_mul(tmp,q,t2);
		mpz_sub(t,t1,tmp);
		
		
		
		mpz_set(r1,r2);
		mpz_set(r2,r);
		mpz_set(s1,s2);
		mpz_set(s2,s);
		mpz_set(t1,t2);
		mpz_set(t2,t);
		
		
			gmp_printf("\nr1 = %Zd | ",r1);
			gmp_printf("r2 = : %Zd | ",r2);
			gmp_printf("s1 = : %Zd | ",s1);
			gmp_printf("s2 = : %Zd | ",s2);
			gmp_printf("t1 = : %Zd | ",t1);
			gmp_printf("t2 = : %Zd\n",t2);
			
	}
	
	gmp_printf("\n\ngcd is : %Zd\n",r1);
	gmp_printf("s = : %Zd\n",s1);
	gmp_printf("t = : %Zd\n",t1);
}
