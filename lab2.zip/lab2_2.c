#include<gmp.h>
#include <time.h>

int main()
{
	gmp_randstate_t grt;
	gmp_randinit_default (grt);
	gmp_randseed_ui (grt, time (NULL));

	mpz_t key_p;
	mpz_init (key_p);

	mpz_urandomb (key_p, grt, 1024);

	if (mpz_even_p (key_p))
		mpz_add_ui (key_p, key_p, 1);

	while (! mpz_probab_prime_p (key_p, 25)> 0)
		mpz_add_ui (key_p, key_p, 2);
		
	gmp_printf ("1024 bits Prime number  is = %Zd \n", key_p);
	return 0;
}
